<div id="sharethis-main-items">
  
  <span class='st_linkedin_custom' st_url="http://www.linkedin.com/" title="LinkedIn" st_title="Sharing Rocks!"></span>
  <span class='st_twitter_custom'  st_url='https://twitter.com/' title="Twitter"></span>
  <span class='st_facebook_large' st_url='http://www.facebook.com/Telenoticias7' displayText='Facebook'></span>
  <span class='st_facebook_custom' st_url='http://www.facebook.com/Telenoticias7' ></span>
  <span class='st_email_custom' st_url='https://www.facebook.com/' title="Email"></span>
  <span class='st_sharethis_custom'></span>
   
</div>
